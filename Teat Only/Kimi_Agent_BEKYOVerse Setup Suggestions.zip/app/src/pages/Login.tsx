import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { BookOpen, Palette, Lock, Mail, ArrowRight } from 'lucide-react';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    setTimeout(() => {
      const success = login(email, password);
      if (!success) {
        setError('Invalid email or password. Please try again.');
      }
      setIsLoading(false);
    }, 800);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      {/* Background Decoration */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-[#e05c4b] rounded-full opacity-5 blur-3xl animate-pulse-slow" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#e05c4b] rounded-full opacity-5 blur-3xl animate-pulse-slow" style={{ animationDelay: '1s' }} />
      </div>

      <div className="w-full max-w-5xl grid lg:grid-cols-2 gap-8 items-center">
        {/* Left Side - Branding */}
        <div className="text-center lg:text-left animate-fade-in-up">
          <div className="flex items-center justify-center lg:justify-start gap-3 mb-6">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#e05c4b] to-[#c94030] flex items-center justify-center animate-float">
              <Palette className="w-7 h-7 text-white" />
            </div>
            <h1 className="text-3xl font-bold font-['Fredoka'] gradient-text">BEKYOVerse</h1>
          </div>
          
          <h2 className="text-4xl lg:text-5xl font-bold mb-4 font-['Fredoka']">
            Online Art <span className="gradient-text">Academy</span>
          </h2>
          
          <p className="text-[var(--text-gray)] text-lg mb-8 max-w-md mx-auto lg:mx-0">
            Learn traditional character drawing and digital art from 
            <span className="text-[var(--primary-red)] font-semibold"> Kyi Zin Thet (Bekyo)</span>
          </p>

          <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
            <div className="glass-card px-5 py-3 flex items-center gap-3">
              <BookOpen className="w-5 h-5 text-[var(--primary-red)]" />
              <span className="text-sm">Traditional Drawing</span>
            </div>
            <div className="glass-card px-5 py-3 flex items-center gap-3">
              <Palette className="w-5 h-5 text-[var(--primary-red)]" />
              <span className="text-sm">Digital Art</span>
            </div>
          </div>
        </div>

        {/* Right Side - Login Form */}
        <div className="animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
          <div className="glass-card p-8 lg:p-10">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold mb-2">Welcome Back</h3>
              <p className="text-[var(--text-gray)] text-sm">Sign in to access your classes</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-sm font-medium mb-2 text-[var(--text-gray)]">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--text-gray)]" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="input-field pl-12"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 text-[var(--text-gray)]">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--text-gray)]" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="input-field pl-12"
                    required
                  />
                </div>
              </div>

              {error && (
                <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="btn-primary w-full flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    Sign In <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>
            </form>

            <div className="mt-6 p-4 rounded-lg bg-[var(--primary-red-dim)] border border-[var(--border-accent)]">
              <p className="text-xs text-[var(--text-gray)] text-center">
                <span className="text-[var(--primary-red)] font-semibold">Demo Login:</span><br />
                Email: demo@bekyoverse.com<br />
                Password: demo123
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

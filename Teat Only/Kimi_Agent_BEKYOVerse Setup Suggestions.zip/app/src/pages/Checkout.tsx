import { useState } from 'react';
import { usePayment, courses } from '../contexts/PaymentContext';
import { ArrowLeft, CreditCard, Lock, CheckCircle, Loader2 } from 'lucide-react';

type PaymentMethod = 'kpay' | 'wave' | 'card';

interface CheckoutProps {
  courseId: string;
  onClose: () => void;
  onSuccess: () => void;
}

export default function Checkout({ courseId, onClose, onSuccess }: CheckoutProps) {
  const { purchaseCourse, getCoursePrice } = usePayment();
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('kpay');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState('');

  const course = courses.find(c => c.id === courseId);
  const price = getCoursePrice(courseId);

  const handlePayment = async () => {
    setIsProcessing(true);
    const success = await purchaseCourse(courseId);
    setIsProcessing(false);
    if (success) {
      setIsComplete(true);
      setTimeout(onSuccess, 2000);
    }
  };

  if (isComplete) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
        <div className="glass-card p-8 text-center max-w-md w-full animate-fade-in-up">
          <div className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-green-500" />
          </div>
          <h3 className="text-2xl font-bold mb-2">Payment Successful!</h3>
          <p className="text-[var(--text-gray)] mb-4">
            You now have full access to {course?.name}
          </p>
          <p className="text-sm text-[var(--primary-red)]">Redirecting to course...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="glass-card w-full max-w-lg max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-[var(--border-faint)] flex items-center gap-4">
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-[var(--card-bg-hover)] transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-xl font-bold">Checkout</h2>
        </div>

        <div className="p-6 space-y-6">
          {/* Course Summary */}
          <div className="p-4 rounded-xl bg-[var(--primary-red-dim)] border border-[var(--border-accent)]">
            <p className="text-sm text-[var(--text-gray)] mb-1">Course</p>
            <h3 className="font-semibold mb-2">{course?.name}</h3>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-[var(--primary-red)]">
                {price.toLocaleString()} MMK
              </span>
            </div>
          </div>

          {/* Payment Methods */}
          <div>
            <p className="text-sm font-medium mb-3">Select Payment Method</p>
            <div className="space-y-3">
              {/* KPay */}
              <label
                className={`flex items-center gap-4 p-4 rounded-xl border cursor-pointer transition-all ${
                  paymentMethod === 'kpay'
                    ? 'border-[var(--primary-red)] bg-[var(--primary-red-dim)]'
                    : 'border-[var(--border-faint)] hover:border-[var(--primary-red)]'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  value="kpay"
                  checked={paymentMethod === 'kpay'}
                  onChange={() => setPaymentMethod('kpay')}
                  className="hidden"
                />
                <div className="w-12 h-12 rounded-lg bg-[#9C27B0] flex items-center justify-center text-white font-bold text-sm">
                  KPay
                </div>
                <div className="flex-1">
                  <p className="font-semibold">KBZ Pay</p>
                  <p className="text-sm text-[var(--text-gray)]">Mobile wallet payment</p>
                </div>
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  paymentMethod === 'kpay' ? 'border-[var(--primary-red)]' : 'border-[var(--border-faint)]'
                }`}>
                  {paymentMethod === 'kpay' && <div className="w-2.5 h-2.5 rounded-full bg-[var(--primary-red)]" />}
                </div>
              </label>

              {/* Wave Pay */}
              <label
                className={`flex items-center gap-4 p-4 rounded-xl border cursor-pointer transition-all ${
                  paymentMethod === 'wave'
                    ? 'border-[var(--primary-red)] bg-[var(--primary-red-dim)]'
                    : 'border-[var(--border-faint)] hover:border-[var(--primary-red)]'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  value="wave"
                  checked={paymentMethod === 'wave'}
                  onChange={() => setPaymentMethod('wave')}
                  className="hidden"
                />
                <div className="w-12 h-12 rounded-lg bg-[#FF6B00] flex items-center justify-center text-white font-bold text-sm">
                  Wave
                </div>
                <div className="flex-1">
                  <p className="font-semibold">Wave Pay</p>
                  <p className="text-sm text-[var(--text-gray)]">Mobile wallet payment</p>
                </div>
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  paymentMethod === 'wave' ? 'border-[var(--primary-red)]' : 'border-[var(--border-faint)]'
                }`}>
                  {paymentMethod === 'wave' && <div className="w-2.5 h-2.5 rounded-full bg-[var(--primary-red)]" />}
                </div>
              </label>

              {/* Card */}
              <label
                className={`flex items-center gap-4 p-4 rounded-xl border cursor-pointer transition-all ${
                  paymentMethod === 'card'
                    ? 'border-[var(--primary-red)] bg-[var(--primary-red-dim)]'
                    : 'border-[var(--border-faint)] hover:border-[var(--primary-red)]'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  value="card"
                  checked={paymentMethod === 'card'}
                  onChange={() => setPaymentMethod('card')}
                  className="hidden"
                />
                <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center text-white">
                  <CreditCard className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold">Credit/Debit Card</p>
                  <p className="text-sm text-[var(--text-gray)]">Visa, MasterCard, JCB</p>
                </div>
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  paymentMethod === 'card' ? 'border-[var(--primary-red)]' : 'border-[var(--border-faint)]'
                }`}>
                  {paymentMethod === 'card' && <div className="w-2.5 h-2.5 rounded-full bg-[var(--primary-red)]" />}
                </div>
              </label>
            </div>
          </div>

          {/* Phone Number for Mobile Payments */}
          {(paymentMethod === 'kpay' || paymentMethod === 'wave') && (
            <div>
              <label className="block text-sm font-medium mb-2">
                Phone Number (for payment confirmation)
              </label>
              <input
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="09XXX XXX XXX"
                className="input-field"
              />
            </div>
          )}

          {/* Card Details */}
          {paymentMethod === 'card' && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Card Number</label>
                <div className="relative">
                  <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--text-gray)]" />
                  <input
                    type="text"
                    placeholder="1234 5678 9012 3456"
                    className="input-field pl-12"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Expiry Date</label>
                  <input
                    type="text"
                    placeholder="MM/YY"
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">CVC</label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--text-gray)]" />
                    <input
                      type="password"
                      placeholder="123"
                      className="input-field pl-12"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Pay Button */}
          <button
            onClick={handlePayment}
            disabled={isProcessing || (paymentMethod !== 'card' && !phoneNumber)}
            className="btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                Pay {price.toLocaleString()} MMK
              </>
            )}
          </button>

          <p className="text-center text-xs text-[var(--text-gray)] flex items-center justify-center gap-1">
            <Lock className="w-3 h-3" />
            Secure payment processing
          </p>
        </div>
      </div>
    </div>
  );
}

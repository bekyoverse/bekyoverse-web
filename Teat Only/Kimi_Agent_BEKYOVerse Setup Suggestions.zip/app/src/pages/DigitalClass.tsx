import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { usePayment } from '../contexts/PaymentContext';
import Checkout from './Checkout';
import { ArrowLeft, Play, Lock, Monitor, Clock, Download, MessageCircle, Palette, LogOut, CreditCard } from 'lucide-react';

const lessons = [
  { id: 1, title: 'Week 1 - Tue: Digital Tools Setup + Sketching', duration: '50:00', week: 1 },
  { id: 2, title: 'Week 1 - Thu: Clean Line Art Techniques', duration: '48:00', week: 1 },
  { id: 3, title: 'Week 2 - Tue: Brush Control & Line Weight', duration: '52:00', week: 2 },
  { id: 4, title: 'Week 2 - Thu: Simple Coloring + Flat Render', duration: '55:00', week: 2 },
  { id: 5, title: 'Week 3 - Tue: Basic Shading & Textures', duration: '58:00', week: 3 },
  { id: 6, title: 'Week 3 - Thu: Mascot Character Design', duration: '60:00', week: 3 },
  { id: 7, title: 'Week 4 - Tue: Emote & Sticker Creation', duration: '55:00', week: 4 },
  { id: 8, title: 'Week 4 - Thu: Final Project + Feedback', duration: '70:00', week: 4 },
];

const software = [
  { name: 'Clip Studio Paint (Required)', icon: '🎨' },
  { name: 'Drawing Tablet', icon: '🖊️' },
  { name: 'Computer or iPad', icon: '💻' },
];

export default function DigitalClass() {
  const { logout } = useAuth();
  const { hasAccess } = usePayment();
  const [activeLesson, setActiveLesson] = useState<number | null>(null);
  const [showCheckout, setShowCheckout] = useState(false);
  const hasPurchased = hasAccess('digital');

  const handleLessonClick = (lessonId: number) => {
    if (hasPurchased) {
      setActiveLesson(lessonId);
    }
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Checkout Modal */}
      {showCheckout && (
        <Checkout
          courseId="digital"
          onClose={() => setShowCheckout(false)}
          onSuccess={() => setShowCheckout(false)}
        />
      )}

      {/* Header */}
      <header className="sticky top-0 z-50 glass-card border-b border-[var(--border-faint)] rounded-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button 
                onClick={() => (window as any).navigateTo('dashboard')}
                className="p-2 rounded-full hover:bg-[var(--card-bg-hover)] transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#e05c4b] to-[#c94030] flex items-center justify-center">
                  <Palette className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold font-['Fredoka'] gradient-text hidden sm:inline">BEKYOVerse</span>
              </div>
            </div>
            
            <button
              onClick={logout}
              className="flex items-center gap-2 px-4 py-2 rounded-full border border-[var(--border-faint)] hover:bg-[var(--primary-red)] hover:border-[var(--primary-red)] transition-all duration-300"
            >
              <LogOut className="w-4 h-4" />
              <span className="text-sm hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-64 lg:h-80 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-600 to-blue-700" />
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-10 left-10 text-8xl">💻</div>
          <div className="absolute bottom-10 right-10 text-8xl">✨</div>
        </div>
        <div className="relative h-full flex items-center max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-3">
              <Monitor className="w-5 h-5 text-white/80" />
              <span className="text-white/80 text-sm font-medium">Digital Art Class</span>
            </div>
            <h1 className="text-3xl lg:text-5xl font-bold text-white mb-3 font-['Fredoka']">
              Digital Art
            </h1>
            <p className="text-white/80 max-w-xl">
              Transform your artistic vision into digital masterpieces. Learn professional digital painting with Clip Studio Paint.
            </p>
          </div>
          {!hasPurchased && (
            <div className="hidden lg:block glass-card p-4 ml-8">
              <p className="text-sm text-[var(--text-gray)] mb-2">Course Price</p>
              <p className="text-3xl font-bold text-[var(--primary-red)] mb-3">75,000 MMK</p>
              <button
                onClick={() => setShowCheckout(true)}
                className="btn-primary w-full flex items-center justify-center gap-2"
              >
                <CreditCard className="w-4 h-4" />
                Buy Now
              </button>
            </div>
          )}
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Video Player or Purchase CTA */}
            <div className="glass-card overflow-hidden">
              {hasPurchased ? (
                activeLesson ? (
                  <div className="aspect-video bg-black flex items-center justify-center relative">
                    <div className="text-center">
                      <Play className="w-16 h-16 text-[var(--primary-red)] mx-auto mb-4" />
                      <p className="text-[var(--text-gray)]">Video Player</p>
                      <p className="text-sm text-[var(--text-gray)] mt-2">
                        {lessons.find(l => l.id === activeLesson)?.title}
                      </p>
                    </div>
                    <button 
                      onClick={() => setActiveLesson(null)}
                      className="absolute top-4 right-4 p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
                    >
                      ✕
                    </button>
                  </div>
                ) : (
                  <div className="aspect-video bg-gradient-to-br from-[var(--dark-red)] to-[var(--body-bg-from)] flex items-center justify-center">
                    <div className="text-center p-8">
                      <div className="text-6xl mb-4">💻</div>
                      <h3 className="text-xl font-bold mb-2">Select a Lesson to Start</h3>
                      <p className="text-[var(--text-gray)] text-sm">Choose from the lesson list below</p>
                    </div>
                  </div>
                )
              ) : (
                <div className="aspect-video bg-gradient-to-br from-[var(--dark-red)] to-[var(--body-bg-from)] flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-black/60" />
                  <div className="relative text-center p-8">
                    <Lock className="w-16 h-16 text-[var(--primary-red)] mx-auto mb-4" />
                    <h3 className="text-2xl font-bold mb-2">Course Locked</h3>
                    <p className="text-[var(--text-gray)] mb-6 max-w-md">
                      Purchase this course to unlock all 8 lessons and start learning!
                    </p>
                    <button
                      onClick={() => setShowCheckout(true)}
                      className="btn-primary flex items-center gap-2 mx-auto"
                    >
                      <CreditCard className="w-5 h-5" />
                      Unlock for 75,000 MMK
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Lesson List */}
            <div className="glass-card p-6">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <Monitor className="w-5 h-5 text-[var(--primary-red)]" />
                Course Content
              </h3>
              <div className="space-y-3">
                {lessons.map((lesson) => (
                  <div
                    key={lesson.id}
                    onClick={() => handleLessonClick(lesson.id)}
                    className={`p-4 rounded-xl border transition-all duration-300 ${
                      !hasPurchased
                        ? 'border-[var(--border-faint)] opacity-60 cursor-not-allowed'
                        : activeLesson === lesson.id
                        ? 'border-[var(--primary-red)] bg-[var(--primary-red-dim)] cursor-pointer'
                        : 'border-[var(--border-faint)] hover:border-[var(--primary-red)] hover:bg-[var(--card-bg-hover)] cursor-pointer'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        !hasPurchased
                          ? 'bg-[var(--card-bg)] text-[var(--text-gray)]'
                          : 'bg-[var(--primary-red-dim)] text-[var(--primary-red)]'
                      }`}>
                        {!hasPurchased ? (
                          <Lock className="w-5 h-5" />
                        ) : (
                          <Play className="w-5 h-5" />
                        )}
                      </div>
                      <div className="flex-1">
                        <h4 className={`font-semibold ${!hasPurchased ? 'text-[var(--text-gray)]' : ''}`}>
                          {lesson.title}
                        </h4>
                      </div>
                      <div className="flex items-center gap-1 text-sm text-[var(--text-gray)]">
                        <Clock className="w-4 h-4" />
                        {lesson.duration}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Purchase Card (if not purchased) */}
            {!hasPurchased && (
              <div className="glass-card p-6 border-[var(--primary-red)]">
                <h3 className="font-bold mb-4 flex items-center gap-2">
                  <Lock className="w-5 h-5 text-[var(--primary-red)]" />
                  Unlock Full Course
                </h3>
                <p className="text-sm text-[var(--text-gray)] mb-4">
                  Get access to all 8 lessons with lifetime access.
                </p>
                <div className="text-3xl font-bold text-[var(--primary-red)] mb-4">
                  75,000 MMK
                </div>
                <button
                  onClick={() => setShowCheckout(true)}
                  className="btn-primary w-full flex items-center justify-center gap-2"
                >
                  <CreditCard className="w-5 h-5" />
                  Purchase Now
                </button>
              </div>
            )}

            {/* Progress Card (if purchased) */}
            {hasPurchased && (
              <div className="glass-card p-6">
                <h3 className="font-bold mb-4">Your Progress</h3>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 rounded-full border-4 border-green-500 flex items-center justify-center">
                    <span className="text-xl font-bold text-green-500">0%</span>
                  </div>
                  <div>
                    <p className="text-sm text-[var(--text-gray)]">0 of 8 lessons completed</p>
                    <p className="text-sm text-green-500 mt-1">Let's get started!</p>
                  </div>
                </div>
                <div className="h-2 bg-[var(--card-bg)] rounded-full overflow-hidden">
                  <div className="h-full w-0 bg-gradient-to-r from-green-500 to-green-400 rounded-full" />
                </div>
              </div>
            )}

            {/* Software Card */}
            <div className="glass-card p-6">
              <h3 className="font-bold mb-4 flex items-center gap-2">
                <Download className="w-5 h-5 text-[var(--primary-red)]" />
                Required Software
              </h3>
              <ul className="space-y-3">
                {software.map((item, index) => (
                  <li key={index} className="flex items-center gap-3 text-sm">
                    <span className="text-xl">{item.icon}</span>
                    <span>{item.name}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-4 p-3 rounded-lg bg-[var(--primary-red-dim)] border border-[var(--border-accent)]">
                <p className="text-xs text-[var(--text-gray)]">
                  <span className="text-[var(--primary-red)] font-semibold">Note:</span> Clip Studio Paint must be purchased separately. Student discount available.
                </p>
              </div>
            </div>

            {/* Instructor Card */}
            <div className="glass-card p-6">
              <h3 className="font-bold mb-4">Instructor</h3>
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#e05c4b] to-[#c94030] flex items-center justify-center text-2xl">
                  👨‍🎨
                </div>
                <div>
                  <p className="font-semibold">Kyi Zin Thet</p>
                  <p className="text-sm text-[var(--primary-red)]">aka Bekyo</p>
                </div>
              </div>
              <button className="w-full mt-4 py-2 rounded-lg border border-[var(--border-faint)] hover:bg-[var(--primary-red)] hover:border-[var(--primary-red)] transition-all duration-300 flex items-center justify-center gap-2 text-sm">
                <MessageCircle className="w-4 h-4" />
                Ask a Question
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { usePayment, courses } from '../contexts/PaymentContext';
import Checkout from './Checkout';
import { BookOpen, Palette, LogOut, User, PlayCircle, Clock, Award, Lock, CheckCircle } from 'lucide-react';

const classData = [
  {
    id: 'traditional',
    title: 'Traditional Character Drawing',
    subtitle: 'Pencil to Cartoon',
    description: 'Learn the fundamentals of character drawing using traditional pencil techniques. Master proportions, expressions, and bring your cartoon characters to life.',
    icon: BookOpen,
    color: 'from-amber-500 to-orange-600',
    lessons: 8,
    duration: '4 weeks',
    level: 'Beginner to Intermediate',
    image: '🎨'
  },
  {
    id: 'digital',
    title: 'Digital Art',
    subtitle: 'Digital Creation',
    description: 'Transform your traditional skills into digital masterpieces. Learn digital painting, coloring techniques, and professional workflow with Clip Studio Paint.',
    icon: Palette,
    color: 'from-cyan-500 to-blue-600',
    lessons: 8,
    duration: '4 weeks',
    level: 'Intermediate to Advanced',
    image: '✨'
  }
];

export default function Dashboard() {
  const { user, logout } = useAuth();
  const { purchasedCourses } = usePayment();
  const [checkoutCourse, setCheckoutCourse] = useState<string | null>(null);

  const navigateToClass = (classId: string) => {
    if ((window as any).navigateTo) {
      (window as any).navigateTo(classId);
    }
  };

  const handleCheckoutSuccess = () => {
    setCheckoutCourse(null);
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Checkout Modal */}
      {checkoutCourse && (
        <Checkout
          courseId={checkoutCourse}
          onClose={() => setCheckoutCourse(null)}
          onSuccess={handleCheckoutSuccess}
        />
      )}

      {/* Header */}
      <header className="sticky top-0 z-50 glass-card border-b border-[var(--border-faint)] rounded-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#e05c4b] to-[#c94030] flex items-center justify-center">
                <Palette className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold font-['Fredoka'] gradient-text">BEKYOVerse</span>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="hidden sm:flex items-center gap-2 glass-card px-4 py-2">
                <User className="w-4 h-4 text-[var(--primary-red)]" />
                <span className="text-sm">{user?.name}</span>
              </div>
              <button
                onClick={logout}
                className="flex items-center gap-2 px-4 py-2 rounded-full border border-[var(--border-faint)] hover:bg-[var(--primary-red)] hover:border-[var(--primary-red)] transition-all duration-300"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm hidden sm:inline">Logout</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Welcome Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12 animate-fade-in-up">
          <h1 className="text-4xl lg:text-5xl font-bold mb-4 font-['Fredoka']">
            Welcome back, <span className="gradient-text">{user?.name.split(' ')[0]}</span>!
          </h1>
          <p className="text-[var(--text-gray)] text-lg max-w-2xl mx-auto">
            Continue your artistic journey with Kyi Zin Thet (Bekyo). 
            Choose a class below to start learning.
          </p>
        </div>

        {/* My Courses Section */}
        {purchasedCourses.length > 0 && (
          <div className="mb-12 animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <CheckCircle className="w-6 h-6 text-green-500" />
              My Courses
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {classData
                .filter(cls => purchasedCourses.includes(cls.id))
                .map((cls) => (
                  <div
                    key={cls.id}
                    onClick={() => navigateToClass(cls.id)}
                    className="glass-card overflow-hidden cursor-pointer group border-green-500/30 hover:border-green-500"
                  >
                    <div className={`h-24 bg-gradient-to-r ${cls.color} relative overflow-hidden`}>
                      <div className="absolute inset-0 flex items-center justify-center text-5xl opacity-30">
                        {cls.image}
                      </div>
                      <div className="absolute top-2 right-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" />
                        Purchased
                      </div>
                    </div>
                    <div className="p-5">
                      <h3 className="font-bold mb-1">{cls.title}</h3>
                      <p className="text-sm text-[var(--primary-red)]">{cls.subtitle}</p>
                      <button className="mt-4 w-full py-2 rounded-lg bg-green-500/20 text-green-500 border border-green-500/30 hover:bg-green-500 hover:text-white transition-all text-sm font-semibold">
                        Continue Learning
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* Available Courses */}
        <div className="animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Lock className="w-6 h-6 text-[var(--primary-red)]" />
            Available Courses
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            {classData
              .filter(cls => !purchasedCourses.includes(cls.id))
              .map((cls, index) => (
                <div
                  key={cls.id}
                  className="glass-card overflow-hidden group"
                  style={{ animationDelay: `${0.3 + index * 0.1}s` }}
                >
                  {/* Card Header */}
                  <div className={`h-32 bg-gradient-to-r ${cls.color} relative overflow-hidden`}>
                    <div className="absolute inset-0 flex items-center justify-center text-6xl opacity-30 group-hover:scale-110 transition-transform duration-500">
                      {cls.image}
                    </div>
                    <div className="absolute bottom-4 left-6">
                      <cls.icon className="w-8 h-8 text-white" />
                    </div>
                    <div className="absolute top-4 right-4 glass-card px-3 py-1">
                      <span className="text-sm font-bold">
                        {courses.find(c => c.id === cls.id)?.price.toLocaleString()} MMK
                      </span>
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-1">{cls.title}</h3>
                    <p className="text-[var(--primary-red)] text-sm font-medium mb-3">{cls.subtitle}</p>
                    <p className="text-[var(--text-gray)] text-sm mb-4 line-clamp-2">
                      {cls.description}
                    </p>

                    {/* Stats */}
                    <div className="flex flex-wrap gap-3 mb-5">
                      <div className="flex items-center gap-1 text-xs text-[var(--text-gray)]">
                        <PlayCircle className="w-4 h-4 text-[var(--primary-red)]" />
                        {cls.lessons} Lessons
                      </div>
                      <div className="flex items-center gap-1 text-xs text-[var(--text-gray)]">
                        <Clock className="w-4 h-4 text-[var(--primary-red)]" />
                        {cls.duration}
                      </div>
                      <div className="flex items-center gap-1 text-xs text-[var(--text-gray)]">
                        <Award className="w-4 h-4 text-[var(--primary-red)]" />
                        {cls.level}
                      </div>
                    </div>

                    {/* Buy Button */}
                    <button
                      onClick={() => setCheckoutCourse(cls.id)}
                      className="w-full py-3 rounded-xl bg-[var(--primary-red)] text-white font-semibold hover:bg-white hover:text-[var(--primary-red)] transition-all duration-300 flex items-center justify-center gap-2"
                    >
                      <Lock className="w-5 h-5" />
                      Buy Course - {courses.find(c => c.id === cls.id)?.price.toLocaleString()} MMK
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Instructor Info */}
        <div className="glass-card p-6 mt-12 max-w-3xl mx-auto animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#e05c4b] to-[#c94030] flex items-center justify-center text-4xl animate-float">
              👨‍🎨
            </div>
            <div className="text-center sm:text-left">
              <h3 className="text-xl font-bold mb-1">Instructor: Kyi Zin Thet</h3>
              <p className="text-[var(--primary-red)] font-medium mb-2">aka Bekyo</p>
              <p className="text-[var(--text-gray)] text-sm">
                Professional animator and illustrator with 5+ years of experience. 
                Creator of GXG Comics and BEKYOVerse studio.
              </p>
            </div>
          </div>
        </div>

        {/* Quick Tips */}
        <div className="mt-16 max-w-3xl mx-auto animate-fade-in-up" style={{ animationDelay: '0.5s' }}>
          <h3 className="text-xl font-bold text-center mb-6">Learning Tips</h3>
          <div className="grid sm:grid-cols-3 gap-4">
            <div className="glass-card p-4 text-center">
              <div className="text-3xl mb-2">📚</div>
              <h4 className="font-semibold text-sm mb-1">Study Regularly</h4>
              <p className="text-xs text-[var(--text-gray)]">Practice 30 mins daily</p>
            </div>
            <div className="glass-card p-4 text-center">
              <div className="text-3xl mb-2">✏️</div>
              <h4 className="font-semibold text-sm mb-1">Take Notes</h4>
              <p className="text-xs text-[var(--text-gray)]">Write down key techniques</p>
            </div>
            <div className="glass-card p-4 text-center">
              <div className="text-3xl mb-2">🎯</div>
              <h4 className="font-semibold text-sm mb-1">Set Goals</h4>
              <p className="text-xs text-[var(--text-gray)]">Complete weekly targets</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

import { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

interface Course {
  id: string;
  name: string;
  price: number;
  currency: string;
}

interface Payment {
  courseId: string;
  amount: number;
  date: string;
  status: 'pending' | 'completed';
}

interface PaymentContextType {
  purchasedCourses: string[];
  payments: Payment[];
  purchaseCourse: (courseId: string) => Promise<boolean>;
  hasAccess: (courseId: string) => boolean;
  getCoursePrice: (courseId: string) => number;
}

const courses: Course[] = [
  { id: 'traditional', name: 'Traditional Character Drawing', price: 50000, currency: 'MMK' },
  { id: 'digital', name: 'Digital Art', price: 75000, currency: 'MMK' },
];

const PaymentContext = createContext<PaymentContextType | undefined>(undefined);

export function PaymentProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [purchasedCourses, setPurchasedCourses] = useState<string[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);

  useEffect(() => {
    if (user) {
      const stored = localStorage.getItem(`bekyoverse_payments_${user.email}`);
      if (stored) {
        const data = JSON.parse(stored);
        setPurchasedCourses(data.courses || []);
        setPayments(data.payments || []);
      }
    }
  }, [user]);

  const savePayments = (courses: string[], paymentList: Payment[]) => {
    if (user) {
      localStorage.setItem(
        `bekyoverse_payments_${user.email}`,
        JSON.stringify({ courses, payments: paymentList })
      );
    }
  };

  const purchaseCourse = async (courseId: string): Promise<boolean> => {
    const course = courses.find(c => c.id === courseId);
    if (!course) return false;

    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 1500));

    const newPayment: Payment = {
      courseId,
      amount: course.price,
      date: new Date().toISOString(),
      status: 'completed',
    };

    const updatedCourses = [...purchasedCourses, courseId];
    const updatedPayments = [...payments, newPayment];

    setPurchasedCourses(updatedCourses);
    setPayments(updatedPayments);
    savePayments(updatedCourses, updatedPayments);

    return true;
  };

  const hasAccess = (courseId: string): boolean => {
    return purchasedCourses.includes(courseId);
  };

  const getCoursePrice = (courseId: string): number => {
    return courses.find(c => c.id === courseId)?.price || 0;
  };

  return (
    <PaymentContext.Provider value={{
      purchasedCourses,
      payments,
      purchaseCourse,
      hasAccess,
      getCoursePrice,
    }}>
      {children}
    </PaymentContext.Provider>
  );
}

export function usePayment() {
  const context = useContext(PaymentContext);
  if (context === undefined) {
    throw new Error('usePayment must be used within a PaymentProvider');
  }
  return context;
}

export { courses };

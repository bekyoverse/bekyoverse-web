import React, { createContext, useContext, useState, useEffect } from 'react';

interface User {
  email: string;
  name: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Pre-authorized students
const AUTHORIZED_STUDENTS = [
  { email: 'student1@bekyoverse.com', password: 'bekyo2025', name: 'Student One' },
  { email: 'student2@bekyoverse.com', password: 'bekyo2025', name: 'Student Two' },
  { email: 'demo@bekyoverse.com', password: 'demo123', name: 'Demo Student' },
];

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    // Check if user is already logged in
    const storedUser = localStorage.getItem('bekyoverse_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const login = (email: string, password: string): boolean => {
    const student = AUTHORIZED_STUDENTS.find(
      (s) => s.email === email && s.password === password
    );
    
    if (student) {
      const userData = { email: student.email, name: student.name };
      setUser(userData);
      localStorage.setItem('bekyoverse_user', JSON.stringify(userData));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('bekyoverse_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { PaymentProvider } from './contexts/PaymentContext';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import TraditionalClass from './pages/TraditionalClass';
import DigitalClass from './pages/DigitalClass';

type Page = 'login' | 'dashboard' | 'traditional' | 'digital';

function AppContent() {
  const { isAuthenticated } = useAuth();
  const [currentPage, setCurrentPage] = useState<Page>('login');

  useEffect(() => {
    if (isAuthenticated && currentPage === 'login') {
      setCurrentPage('dashboard');
    } else if (!isAuthenticated) {
      setCurrentPage('login');
    }
  }, [isAuthenticated, currentPage]);

  // Navigation helper
  useEffect(() => {
    (window as any).navigateTo = (page: Page) => {
      setCurrentPage(page);
    };
  }, []);

  const renderPage = () => {
    switch (currentPage) {
      case 'login':
        return <Login />;
      case 'dashboard':
        return <Dashboard />;
      case 'traditional':
        return <TraditionalClass />;
      case 'digital':
        return <DigitalClass />;
      default:
        return <Login />;
    }
  };

  return (
    <div className="min-h-screen">
      {renderPage()}
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <PaymentProvider>
        <AppContent />
      </PaymentProvider>
    </AuthProvider>
  );
}

export default App;
